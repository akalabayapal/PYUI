from PYUI.Package.PYUI import PYUI,Component,Element,cpath
from code.sock.server import ThreadedSocketServer
class HandleServer:

    def __init__(self,obj:PYUI,):
        
        self.pyui = obj
        self.server = ThreadedSocketServer(self.handle_recv)
        self.host =    self.server.host
        self.port = self.server.port
        


        self.msg_component = Component(
            self.pyui,
            'dash/msg'
        )

        self.msglist = Element(
            cpath('server','ml'),
            self.pyui
        )

        self.end  = Element(
            cpath('server','stop'),
            self.pyui
        )


        self.send = Element(
            cpath('server','send'),
            self.pyui
        )

        self.msgbox = Element(
            cpath('server','text'),
            self.pyui
        )

        self.end.on(
            'click',
            self.stop_onclick
        )
        
        self.send.on(
            'click',
            self.send_onclick
        )

        self.compList =   []

    def handle_recv(self,msg):

        #add to msglist
        id = self.msg_component.appendComponent(
            self.msglist.id,
            user_id='CLIENT',
            msg=msg
        )
        self.compList.append(id)


        
    def activate(self):

        room_id =  cpath('server','rid')

        self.roomid_txt = Element(room_id,self.pyui)
        self.roomid_txt.text = f'sock://{self.host}:{self.port}'

        return self.server

    def stop_onclick(self,o,m):
        self.server.stop()

        for id in self.compList:
            self.msg_component.removeComponent(id)
        
        self.compList = []

        self.roomid_txt.text = ''
        self.msgbox.attrib.value = ''

        self.pyui.changeWindow('view_front')

    def send_onclick(self,o,m):
  
        msg = str(self.msgbox.attrib.value).strip().replace("'","")
  
        if msg  == '':
            return
        self.server.send_to_all(msg)

        #add to msglist
        id = self.msg_component.appendComponent(
            self.msglist.id,
            user_id='SERVER',
            msg=msg
        )
        self.compList.append(id)
        self.msgbox.attrib.value = ''