from PYUI.Package.PYUI import PYUI,Component,Element,cpath
from code.sock.client import CustomSocketClient
from PYUI.Package.PYUI import PYUI
import time

class HandleClient:

    def __init__(self,pyui:PYUI):

 

        self.pyui = pyui
        
      


        self.msg_component = Component(
            self.pyui,
            'dash/msg'
        )

        self.msglist = Element(
            cpath('client','ml'),
            self.pyui
        )

        self.end  = Element(
            cpath('client','stop'),
            self.pyui
        )


        self.send = Element(
            cpath('client','send'),
            self.pyui
        )

        self.msgbox = Element(
            cpath('client','text'),
            self.pyui
        )

        try:
            self.end.on(
            'click',
            self.stop_onclick
            )
        
            self.send.on(
            'click',
            self.send_onclick
            )
        except:
            pass

        self.compList =   []

    def activate(self,room):

        room_id =  cpath('client','rid')

        

        self.client = CustomSocketClient(room,self.handle_recv)
        self.host = self.client.host
        self.port = self.client.port

        self.pyui = self.pyui
        
        self.host =    self.client.host
        self.port = self.client.port

        self.roomid_txt = Element(room_id,self.pyui)
        self.roomid_txt.text = f'sock://{self.host}:{self.port}'

        return self.client.connect()
    
    def handle_recv(self,msg):

        #add to msglist
        id = self.msg_component.appendComponent(
            self.msglist.id,
            user_id='SERVER',
            msg=msg
        )
        self.compList.append(id)

    def stop_onclick(self,o,m):
        self.client.close()

        self.msgbox.attrib.value  = ''

        for id in self.compList:
            self.msg_component.removeComponent(id)
        
        self.compList = []

        self.roomid_txt.text = ''
        self.msgbox.attrib.value = ''
        self.pyui.setText(cpath('client','err'),'')

        self.pyui.changeWindow('view_front')

 

    def send_onclick(self,o,m):
  
        msg = str(self.msgbox.attrib.value).strip().replace("'","")
  
        if msg  == '':
            return
        if not self.client.is_running:
            self.pyui.setText(cpath('client','err'),'Server disconnected.')
            time.sleep(5)
            self.stop_onclick(self.pyui,'')

        self.client.send(msg)
            

        #add to msglist
        id = self.msg_component.appendComponent(
            self.msglist.id,
            user_id='CLIENT',
            msg=msg
        )
        self.compList.append(id)
        self.msgbox.attrib.value = ''


