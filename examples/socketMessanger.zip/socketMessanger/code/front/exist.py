from  PYUI.Package.PYUI import PYUI,Element,Component,cpath
from code.dash.client import HandleClient
class HandleExisting:

    def __init__(self,obj:PYUI):

        self.pyui = obj
        self.h = HandleClient(self.pyui)


        self.inp = Element(
            cpath('old_room','inp'),
            self.pyui
        )

        self.enter_btn = Element(
            cpath('old_room','enter'),
            self.pyui
        )

        self.gb = Element(
            cpath('old_room','gb'),
            self.pyui
        )

        self.err_msg = Element(
            cpath('old_room','err_txt'),
            self.pyui
        )

        self.enter_btn.on(
            'click',
            self.enter_onclick
        )

        self.gb.on(
            'click',
            self.gb_onclick
        )

    def enter_onclick(self,o,m):

        self.err_msg.text =  ''

        room_sock = str(self.inp.attrib.value ).replace("'",'').strip()

        if room_sock == '':
            self.err_msg.text = 'Please enter a correct uri'
            self.err_msg.style.color = 'red'
            return
        self.inp.attrib.value = ''
     
        if self.h.activate(room_sock):
            
             self.pyui.changeWindow('client_view')
        else:
            print("here")
            self.err_msg.text = 'Invalid Server uri'       
            self.err_msg.style.color = 'red'


        

    def gb_onclick(self,o,m):
        self.err_msg.text =  ''
        self.pyui.changeWindow('view_front')