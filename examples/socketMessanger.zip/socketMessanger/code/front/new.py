from  PYUI.Package.PYUI import PYUI,Element,Component,cpath

from code.dash.server import  HandleServer

class HandleNew:

    def __init__(self,obj:PYUI):
        
        self.pyui = obj

        self.dash = HandleServer(obj)

        id_gb = cpath('new_room','gb')
        id_go = cpath('new_room','go')

        id_mkroom = cpath("new_room",'mkroom')
        id_room_id = cpath('new_room','room_id')

        self.gb  = Element(id_gb,self.pyui)
        self.go = Element(id_go,self.pyui)

        self.mkroom = Element(id_mkroom,self.pyui)
        self.roomid =  Element(id_room_id,self.pyui)

        # Register go-back callback
        self.gb.on(
            'click',
            self.gb_onclick
        )

        # register makeroom btn
        self.mkroom.on(
            'click',
            self.mkroom_onclick
        )

        #register go btn
        self.go.on(
            'click',
            self.go_onclick
        )

    def gb_onclick(self,o,m):

        # clean up the room
        self.roomid.attrib.value = 'No Rooms Made'
        self.go.attrib.disabled = True
        self.mkroom.attrib.disabled = False
        self.go.attrib.disabled = True #disable the btn

        try:
            self.server.stop()   #stop the server
        except:
            pass

        self.pyui.changeWindow('view_front')
    
    def mkroom_onclick(self,o,m):
        #disable the mkroom btn
        self.server = self.dash.activate()


        self.mkroom.attrib.disabled = True


        self.roomid.attrib.value = f'sock://{self.server.host}:{self.server.port}'
        self.go.attrib.disabled = False #enable the btn

        # start
        self.server.start()


    def go_onclick(self,o,m):

        # open server page....
        self.pyui.changeWindow('server_view')
        


        self.roomid.attrib.value = 'No Rooms Made'
        self.go.attrib.disabled = True
        self.mkroom.attrib.disabled = False
        self.go.attrib.disabled = True #disable the btn

