from PYUI.Package.PYUI import PYUI,Element,Component,cpath
from code.front.new import HandleNew
from code.front.exist import HandleExisting
'''
Element: OPP facade over procedural PYUI
Component: Add and remove dynamic components from UI
cpath: helps is easy resolving component ids you need not write "component_id_element_id" better use cpath(component_id,element_id)
both are equivalent.
'''

class Front:

    def __init__(self,obj:PYUI):

        '''
        Entry point of App class.
        Use this class to work with DOM UI
        '''
        self.pyui = obj

        # Register the buttons for entering room and new room
        self.hnew = HandleNew(self.pyui)

        self.hext = HandleExisting(self.pyui)


        btn_existing = Element('btn_enter_room',self.pyui)
        btn_new = Element('btn_create_room',self.pyui)

        btn_existing.on(
            'click',
            self.btn_existing_onclick
        )

        btn_new.on(
            'click',
            self.btn_new_onclick
        )

    def btn_existing_onclick(self,o,m):

        self.pyui.changeWindow('enter_room')

    def btn_new_onclick(self,o,m):

        self.pyui.changeWindow('new_room')

def entry(obj:PYUI):
    
    '''
    This is the entry point for your form index.xml
    You can write procedural code using this entrypoint by deleting OPP function. Or use the boilerplate App class
    You can rename the Class to anything
    '''
    Front(obj) # executing the app class