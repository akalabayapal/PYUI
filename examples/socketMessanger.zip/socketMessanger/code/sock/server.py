import socket
import threading

class ThreadedSocketServer:


    def __init__(self,handle_recv, port: int = 65432):
        self.host = self._get_local_ipv4()  # Dynamically fetches the local IPv4 address
        self.port = port
        self.server_socket = None
        self.is_running = False
        self.msg_handler = handle_recv
        self._listen_thread = None
        self.clients = set()
        self.clients_lock = threading.Lock()

    def _get_local_ipv4(self) -> str:
        """Automatically detects the machine's local IPv4 network address."""
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        try:
            # Does not actually connect or send data; used to find the interface routing to the internet
            s.connect(("8.8.8.8", 80))
            local_ip = s.getsockname()[0]
        except Exception:
            # Fallback to local hostname resolution if network is offline
            try:
                local_ip = socket.gethostbyname(socket.gethostname())
            except Exception:
                local_ip = '127.0.0.1'
        finally:
            s.close()
        return local_ip

    def start(self):
        """Starts the socket server in a separate thread."""
        self.server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.server_socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        self.server_socket.bind((self.host, self.port))
        self.server_socket.listen()
        
        self.is_running = True
        print(f"[SERVER] Started on local network IP: {self.host}:{self.port}")
        print(f"[SERVER] Other devices on this Wi-Fi/LAN can connect to this IP.")
        
        self._listen_thread = threading.Thread(target=self._listen_loop, daemon=True)
        self._listen_thread.start()

    def _listen_loop(self):
        """Internal loop to accept incoming client connections."""
        while self.is_running:
            try:
                self.server_socket.settimeout(1.0)
                client_socket, client_address = self.server_socket.accept()
                print(f"[SERVER] Connection accepted from {client_address}")
                
                with self.clients_lock:
                    self.clients.add(client_socket)
                
                client_thread = threading.Thread(
                    target=self._handle_client, 
                    args=(client_socket,), 
                    daemon=True
                )
                client_thread.start()
            except socket.timeout:
                continue
            except Exception as e:
                if self.is_running:
                    print(f"[SERVER] Error accepting connection: {e}")
                break

    def _handle_client(self, client_socket: socket.socket):
        """Internal method to manage communication with a single client."""
        try:
            while self.is_running:
                data = client_socket.recv(1024)
                if not data:
                    break
                
                incoming_msg = data.decode('utf-8')
                self.msg_handler(incoming_msg)
                #client_socket.sendall(response.encode('utf-8'))
                
        except Exception as e:
            if self.is_running:
                print(f"[SERVER] Client communication error: {e}")
        finally:
            with self.clients_lock:
                self.clients.discard(client_socket)
            client_socket.close()
            print("[SERVER] Client disconnected")

    def send_to_all(self, message: str):
        """Sends a message out to all currently connected clients."""
        if not self.is_running:
            print("[SERVER] Cannot send message, server is not running.")
            return

        print(f"[SERVER] Broadcasting: {message}")
        encoded_msg = message.encode('utf-8')
        
        with self.clients_lock:
            disconnected_clients = []
            for client in self.clients:
                try:
                    client.sendall(encoded_msg)
                except Exception as e:
                    print(f"[SERVER] Failed to send to a client: {e}")
                    disconnected_clients.append(client)
            
            for client in disconnected_clients:
                self.clients.discard(client)

    def stop(self):
        """Safely stops the server and closes all sockets."""
        print("[SERVER] Shutting down...")
        self.is_running = False
        
        with self.clients_lock:
            for client in self.clients:
                try:
                    client.close()
                except:
                    pass
            self.clients.clear()
        
        if self.server_socket:
            try:
                self.server_socket.close()
            except Exception as e:
                print(f"[SERVER] Error closing main socket: {e}")
                
        if self._listen_thread:
            self._listen_thread.join()
        print("[SERVER] Stopped successfully.")


