import socket
import threading
from urllib.parse import urlparse

class CustomSocketClient:
    def __init__(self, uri: str, on_message_callback):
        """
        Initializes the socket client.
        
        :param uri: String in the format 'sock://host:port'
        :param on_message_callback: Function called when a message is received. 
                                    Expected signature: callback(message_str)
        """
        self.uri = uri
        self.on_message = on_message_callback
        self.client_socket = None
        self.is_running = False
        self.listener_thread = None
        
        # Parse the custom URI
        self._parse_uri()

    def _parse_uri(self):
        # urlparse needs a standard-looking URL, so we handle sock:// smoothly
        parsed = urlparse(self.uri)
        
        if parsed.scheme != "sock":
            raise ValueError("Invalid URI scheme. Expected 'sock://'")
        
        if not parsed.hostname or not parsed.port:
            raise ValueError("URI must include both a hostname and a port (e.g., sock://localhost:8080)")
            
        self.host = parsed.hostname
        self.port = parsed.port

    def connect(self):
        """Establishes connection to the server and starts the listening thread."""
        try:
            self.client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            self.client_socket.connect((self.host, self.port))
            self.is_running = True
            
            # Start background thread to listen for incoming messages
            self.listener_thread = threading.Thread(target=self._listen_loop, daemon=True)
            self.listener_thread.start()
            return True
        except Exception as e:
            self.close()
            return False

    def _listen_loop(self):
        """Internal loop running in a background thread to receive data."""
        while self.is_running:
            try:
                # Receives up to 4096 bytes
                data = self.client_socket.recv(4096)
                if not data:
                    # Server closed the connection
                    print("\n[Server disconnected]")
                    self.close()
                    break
                
                # Decode and pass message to the user-defined callback
                message = data.decode('utf-8')
                self.on_message(message)
                
            except Exception as e:
                if self.is_running:
                    print(f"\nError receiving data: {e}")
                break

    def send(self, message: str):
        """Sends a string message to the connected socket server."""
        if not self.client_socket or not self.is_running:
            print("Cannot send message. Client is not connected.")
            return False
            
        try:
            self.client_socket.sendall(message.encode('utf-8'))
            return True
        except Exception as e:
            print(f"Failed to send message: {e}")
            return      False
            self.close()

    def close(self):
        """Closes the socket connection gracefully."""
        self.is_running = False
        if self.client_socket:
            try:
                self.client_socket.close()
            except Exception:
                pass
        print("Connection closed.")