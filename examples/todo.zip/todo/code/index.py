from PYUI.Package.PYUI import PYUI,Element,Component,cpath,Pipeline

class Todo:

    def __init__(self,obj:PYUI):
        self.pyui:PYUI = obj

        #work count
        self.work_count_ui = Element('task-count',obj)

        # register the add btn
        self.btn_add = Element('btn-add',obj)
        self.btn_add.on('click',self.addWork)

        #input btn
        self.work_inp = Element('todo-input',obj)

        #main work list
        self.work_list = Element('tasks-list',obj)

        #load components
        self.row = Component(obj,'row')

        #work count
        self.work_count = 0

    def updateWorkPending(self):
        self.work_count_ui.text = str(self.work_count)

    def addWork(self,o,m):
        work_name = self.work_inp.attrib.value #store the value

        # add component
        eid,top = self.work_list + self.row.object(work_name=work_name)

        self.work_inp.attrib.value = "" # empty it 

        eid_cont = eid[0]

        # add eventlistener to delete buttons and mark as complete
        self.pyui.RegisterCallback(eid_cont+"_"+'btn_del','click',self.workDel,args=(eid_cont,)) 
        self.pyui.RegisterCallback(eid_cont+'_'+'btn_check','click',self.markasComplete,args=(eid_cont,))

        #increment no of works
        self.work_count += 1

        #update pending
        self.updateWorkPending()


    def workDel(self,o,m,uid):

        self.row.removeComponent(uid)
        self.work_count -=1
        self.updateWorkPending()

    def markasComplete(self,o,m,uid):

        task_txt = Element(cpath(uid,'text_task'),self.pyui) # the task text
        del_btn = Element(cpath(uid,'btn_del'),self.pyui)
        check_box = Element(cpath(uid,'btn_check'),self.pyui)

        val = check_box.attrib.checked
        p = Pipeline() + task_txt.set_style + task_txt.set_style + del_btn.set_attribute
       
        if val:

            p.flush(self.pyui,
                [
                    ('text-decoration','line-through'),
                    ('color','grey'),
                    ('disabled',True)
                ]
            )
            # task_txt.style.textDecoration = "line-through"
            # task_txt.style.color = 'grey'
            # del_btn.attrib.disabled = True
            self.work_count -= 1
        else:
            p.flush(self.pyui,
                [
                    ('text-decoration',''),
                    ('color','white'),
                    ('disabled',False)
                ]
            )
          
            # task_txt.style.textDecoration = ""
            # task_txt.style.color = 'white'
            # del_btn.attrib.disabled = False

            self.work_count += 1
        self.updateWorkPending()
    
        

        


def entry(obj:PYUI):
    
    # open up todo class
    Todo(obj)
    